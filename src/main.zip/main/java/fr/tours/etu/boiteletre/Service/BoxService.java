package fr.tours.etu.boiteletre.Service;

import fr.tours.etu.boiteletre.DTO.DtoForBox.BoxDTO;
import fr.tours.etu.boiteletre.MappStruct.BoxMapper;
import fr.tours.etu.boiteletre.Model.Box;
import fr.tours.etu.boiteletre.Repository.BoxRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
/**
 *  A service Class for the Box entity
 *
 * @author Coulibaly Mamadou & Radia MERABTENE
 * @version 1.0
 */
@Service
@RequiredArgsConstructor
public class BoxService {
    /**
     * a boxRepository object
     */
    private final BoxRepository boxRepository;
    /**
     * a Boxmapper Object
     */
    private final BoxMapper boxMapper;

    /**
     * creating a new BoxDTO
     * @param boxDTO
     * @return the created boxDTO
     */
    public  BoxDTO createBox(BoxDTO boxDTO){

        Box box = boxMapper.dtoToBox(boxDTO);
        Box saveBox = boxRepository.save(box);

        BoxDTO dtoBox = boxMapper.boxToDto(saveBox);

        return new  BoxDTO(dtoBox);
    }

    /**
     * read all the list of the Boxes from the database
     * @return a BoxDTO list
     */
    public List<BoxDTO> getAllBox(){
        List<Box> boxList = boxRepository.findAll();
        List<BoxDTO> responseBoxDTOList = new ArrayList<>();

        if (!boxList.isEmpty()){
            for (Box b : boxList) {
                responseBoxDTOList.add(new BoxDTO(boxMapper.boxToDto(b)));
            }
        }
        return responseBoxDTOList;
    }

    /**
     * get a specific box that machs the id in the parameter
     * @param id : int the id of the box to read
     * @return a BoxDTO
     */
    public  BoxDTO getBoxById(int id){
        Box box = boxRepository.findById(id).orElseThrow(()-> new IllegalArgumentException("The box with the id : " + id + " doesn't exist!"));

        return new  BoxDTO(boxMapper.boxToDto(box));
    }

    /**
     * update a specific box according to the id in the parameter
     * @param id : int the id of the box to update
     * @param boxDTO : the box containing the new values
     * @return BoxDTO
     */
    public BoxDTO updateBox(int id, BoxDTO boxDTO){
        Box box = boxRepository.findById(id).orElseThrow(()-> new IllegalArgumentException("The box with the id : " + id + " doesn't exist!"));

        box.setName(boxDTO.getName());
        box.setQuantity(boxDTO.getQuantity());
        box.setDescription(boxDTO.getDescription());

        return new BoxDTO(boxMapper.boxToDto(boxRepository.save(box)));
    }

    /**
     * delete a box of the given id in the parameter
     * @param id int : the id of the box to delete
     */
    public void deleteBoxById(int id){

        if (boxRepository.existsById(id)){
            boxRepository.deleteById(id);
        }else{
            throw new IllegalArgumentException("The box with the id : " + id + " doesn't exist!");
        }

    }

}
