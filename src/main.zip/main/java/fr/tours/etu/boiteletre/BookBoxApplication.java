package fr.tours.etu.boiteletre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookBoxApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookBoxApplication.class, args);
	}

}
